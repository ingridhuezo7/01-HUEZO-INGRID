import pandas as pd 
import numpy as np 
from datetime import datetime, date, time, timedelta
import calendar


from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches
#-------------------------
#Ingresar credenciales
#Usuario: 'Emtech'
#Contraseña: 'Python'

if __name__ == "__main__":
    USUARIO = 'Emtech'
    CONTRASENA = 'Python'
    INTENTOS = 2

    while True: 
      if INTENTOS == 0:
                  exit()

      username = input ('Ingresa el usuario: ')
      password = input ('Ingresa la contraseña: ')
          
      if username == USUARIO:
            if password == CONTRASENA:
                break

      else:
               INTENTOS = INTENTOS - 1
      print(f'\n¡Usuario/Contraseña incorrecto(s), {INTENTOS} restante!\n')
print(f"\n\n\n¡Bienvenido {USUARIO}!")
#--------------------------

#1. Diccionario de productos, searches & sales

#Searches

l_search=[]
l_product=[]
for lse in lifestore_searches:
  l_search.append(lse[0])
  l_product.append(lse[1])
df_Searches=pd.DataFrame({'id_searches':l_search,'id_product':l_product})
#Relación id search & id product
#print(df_Searches)

#Promediar los searches por id buscado
l_product1se=list(set(l_product))
df_Searches1=df_Searches.sort_values(by=('id_searches'), ascending=True)
l_product1se=list(set(l_product))
l_searches1se=[]
for sea in l_product1se:
    l_searches1se.append(df_Searches.loc[(df_Searches['id_product'] == sea),['id_searches']]['id_searches'].count())
df_modeSearch=pd.DataFrame({'id_product': l_product1se,
'id_searches':l_searches1se})
#Ordenar productos con mayores búsquedas
df_modeSearch=df_modeSearch.sort_values(by='id_searches', ascending=False)
#10 productos con mayores búsquedas
#print (df_modeSearch.head(10))
#10 productos con menores búsquedas
#print (df_modeSearch.tail(10))
#-------------------------------------------------------------
#Sales

l_idSale=[]
l_product=[]
l_score=[]
l_date=[]
l_refund=[]
for lsa in lifestore_sales:
  l_idSale.append(lsa[0])
  l_product.append(lsa[1])
  l_score.append(lsa[2])
  l_date.append(lsa[3])
  l_refund.append(lsa[4])
df_Sales=pd.DataFrame({'id_sale':l_idSale,
'id_product':l_product,
'score':l_score,
'date':l_date,
'refund':l_refund})
#Relación de todos los rubros de Sales
#print (df_Sales)
#**********************************************************************
#Promediar los scores por id
df_Sales=df_Sales.sort_values(by=('score'), ascending=False)
l_product1=list(set(l_product))
l_score1=[]
for p in l_product1:
    l_score1.append(df_Sales.loc[(df_Sales['id_product'] == p),['score']]['score'].mean())
df_meanScore=pd.DataFrame({'id_product': l_product1,
'score':l_score1})
df_meanScore=df_meanScore.sort_values(by='score', ascending=False)
#5 mejores productos por reseña
#print(df_meanScore.head(5))
#5 peores productos por reseña
#print(df_meanScore.tail(5))

l_product1=list(set(l_product))
l_date1=list(set(l_date))
l_idSale1=[]
for sa in l_product1:
    l_idSale1.append(df_Sales.loc[(df_Sales['id_product'] == sa),['id_sale']]['id_sale'].count())
df_modeSale=pd.DataFrame({'id_product': l_product1,
'id_sale':l_idSale1})
#Ordenar productos con mayores ventas
df_modeSale=df_modeSale.sort_values(by='id_sale', ascending=False)
#5 productos con mayores ventas en general
#print (df_modeSale.head(5))
#5 productos con menores ventas en general
#print (df_modeSale.tail(5))

#-------------------------------------------------------------------

#Products

l_product=[]
l_name=[]
l_price=[]
l_category=[]
l_stock=[]
for lp in lifestore_products:
  l_product.append(lp[0])
  l_name.append(lp[1])
  l_price.append(lp[2])
  l_category.append(lp[3])
  l_stock.append(lp[4])
df_Product=pd.DataFrame({'id_product':l_product,
'name':l_name,
'price':l_price,
'category':l_category,
'stock':l_stock})
df_Product=df_Product.sort_values(by='stock', ascending=False)
#Stock por producto en orden de mayor a menor stock
#print (df_Product.head(10))

#Obtener lista de categorias únicas

df_category=df_Product['category'].drop_duplicates()
df_category=df_category.reset_index()
df_category= df_category['category']
#Ennumerar categorías
#print(df_category)
df1=df_Searches.merge(df_Product[['id_product','category']], how='left', on='id_product')
#Lista de productos por categoría a la que pertenecen
#print(df1)

#**************************************************************

#Conteo de búsquedas por categoría y suma de precio si es venta o no 

lista_searches=[]

for l in df_category:
    lista_searches.append(len(df1.loc[df1['category']==l,['category']]))

df_searchescount=pd.DataFrame({'category':df_category,
                               'searches':lista_searches})
df_searchescount=df_searchescount.sort_values(by='searches', ascending=False)
#Cantidad de búsquedas por categoría
#print(df_searchescount)

#Relación tabla Sales/Product
df2=df_Sales.merge(df_Product[['id_product','category','price']], how='left', on='id_product')
#print(df2)

#***********************************************************

#Productos con mayores ventas

lista_ventas=[]

for s in df_category:
#condicion que te filtra la categoria y que haya sido venta(no refund)
    lista_ventas.append(df2.loc[(df2['category'] == s) & (df2['refund']==0),['price']]['price'].sum())

df_salesum=pd.DataFrame({'category':df_category,
'sales':lista_ventas})
df_salesum=df_salesum.sort_values(by='sales', ascending=False)
#Ganancias por categoría mayores a menores
#print(df_salesum)

#***************************************************

#Ventas válidas
ventas=[]
for sale in lifestore_sales:
  #refund=sale[-1] es igual al de abajo
  refund=sale[4]
  if refund ==1:
    continue
  else:
    ventas.append(sale)
  # ó if refund == 0:
#for venta in ventas:
  #print (venta) #Ya tiene las ventas válidas, no incluye reembolsos.

#Ventas por mes

meses = ['/01/', '/02/', '/03/', '/04/','/05/','/06/','/07/','/08/','/09/','/10/','/11/','/12/']
ventas_por_mes=[]
for mes in meses:
  lista_vacia=[]
  ventas_por_mes.append(lista_vacia)
for venta in ventas:
  id_venta=venta[0]
  fecha = venta[3]
  
  contador_del_mes = 0
  for mes in meses:
    if mes in fecha:
      ventas_por_mes[contador_del_mes].append(id_venta)
      continue
    contador_del_mes=contador_del_mes + 1

contador_de_mes = 0
for venta_mensual in ventas_por_mes:
  #print (venta_mensual) #sale id's por mes
  #print (f'¡En el mes de {meses[contador_de_mes]} hubo {len(venta_mensual)} ventas!')
  contador_de_mes = contador_de_mes + 1

#***********************************************************

#Obtener las ganancias mensuales
monthly_gain=[]
for venta_mensual in ventas_por_mes:
    month_gain = 0
    for id_venta in venta_mensual:
        indice_de_venta = id_venta - 1
        info_de_venta = lifestore_sales[indice_de_venta]
        id_prod = info_de_venta[1]
        indice_de_prod = id_prod - 1
        info_del_prod = lifestore_products[indice_de_prod]
        precio_de_prod = info_del_prod[2]
        month_gain = month_gain + precio_de_prod
    monthly_gain.append(month_gain)

#print(monthly_gain)

#************************

#Ordenar ventas del mes con id
lista_prev=[]
for mes,gain in enumerate(monthly_gain):
  sublista= [gain, mes]
  lista_prev.append(sublista)
  lista_prev.sort(reverse=True)
#total de ganancias por mes
#for lista in lista_prev:
  #print (lista) 